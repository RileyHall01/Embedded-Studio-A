
// dht11_reader.v
// Reads temperature and humidity from the DHT11 sensor.
// Checks the received data before updating the measurements.

module dht11_reader #(
    parameter CLK_HZ   = 50_000_000,
    parameter PWRUP_MS = 1500,   // Initial sensor settling time
    parameter POLL_MS  = 2000    // Time between readings
)(
    input  wire       clk,
    input  wire       rst_n,
    inout  wire       dht_data,
    output reg  [7:0] temp_c,
    output reg  [3:0] temp_tenths,
    output reg  [7:0] humidity,
    output reg        data_valid,
    output reg        read_ok
);

    // Timing values for the DHT11 communication protocol
    localparam integer TICKS_PER_US  = CLK_HZ / 1_000_000;
    localparam integer PWRUP_US      = PWRUP_MS * 1000;
    localparam integer POLL_US       = POLL_MS  * 1000;
    localparam integer START_LOW_US  = 20_000;
    localparam integer TIMEOUT_US    = 150;
    localparam integer BIT_THRESH_US = 45;

    localparam [3:0]
        ST_PWRUP     = 4'd0,
        ST_START_LOW = 4'd1,
        ST_REL_HIGH  = 4'd2,
        ST_RESP_WAIT = 4'd3,
        ST_RESP_LOW  = 4'd4,
        ST_RESP_HIGH = 4'd5,
        ST_BIT_LOW   = 4'd6,
        ST_BIT_HIGH  = 4'd7,
        ST_CHECK     = 4'd8,
        ST_WAIT      = 4'd9;

    reg [3:0]  state;
    reg [21:0] us_cnt;
    reg [7:0]  tick_cnt;
    reg        tick;
    reg [39:0] shift;
    reg [5:0]  bit_cnt;
    reg        dht_oe;

    // Only pull the data line low or release it
    assign dht_data = dht_oe ? 1'b0 : 1'bz;

    // Synchronise the sensor signal to the FPGA clock
    reg din_m, din_s;
    always @(posedge clk) begin
        din_m <= dht_data;
        din_s <= din_m;
    end

    // Separate the five bytes received from the sensor
    wire [7:0] hum_i = shift[39:32];
    wire [7:0] hum_d = shift[31:24];
    wire [7:0] tmp_i = shift[23:16];
    wire [7:0] tmp_d = shift[15:8];
    wire [7:0] csum  = shift[7:0];
    wire [7:0] sum   = hum_i + hum_d + tmp_i + tmp_d;

    // Apply the provisional humidity correction observed during testing
    // and interpret temperature using the previous working format
    wire [7:0]  humidity_corrected = (hum_i >= 8'd100) ? (hum_i - 8'd100) : hum_i;
    wire [15:0] temp_deci = ({8'd0, tmp_i} * 16'd10) + {8'd0, tmp_d};
    wire        frame_ok = (sum == csum) && (humidity_corrected <= 8'd100)
                             && (temp_deci <= 16'd600);

    wire timeout = (us_cnt >= TIMEOUT_US);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state       <= ST_PWRUP;
            us_cnt      <= 22'd0;
            tick_cnt    <= 8'd0;
            tick        <= 1'b0;
            shift       <= 40'd0;
            bit_cnt     <= 6'd0;
            dht_oe      <= 1'b0;
            temp_c      <= 8'd0;
            temp_tenths <= 4'd0;
            humidity    <= 8'd0;
            data_valid  <= 1'b0;
            read_ok     <= 1'b0;
        end else begin
            data_valid <= 1'b0;

            // Generate a 1 microsecond timing pulse
            if (tick_cnt == TICKS_PER_US - 1) begin
                tick_cnt <= 8'd0;
                tick     <= 1'b1;
            end else begin
                tick_cnt <= tick_cnt + 1'b1;
                tick     <= 1'b0;
            end
            if (tick) us_cnt <= us_cnt + 1'b1;

            case (state)
                ST_PWRUP: begin
                    if (us_cnt >= PWRUP_US) begin
                        us_cnt <= 22'd0;
                        state  <= ST_START_LOW;
                    end
                end

                // Pull the line low to request a reading
                ST_START_LOW: begin
                    dht_oe <= 1'b1;
                    if (us_cnt >= START_LOW_US) begin
                        dht_oe <= 1'b0;
                        us_cnt <= 22'd0;
                        state  <= ST_REL_HIGH;
                    end
                end

                // Wait for the sensor's response
                ST_REL_HIGH: begin
                    if (din_s) begin us_cnt <= 22'd0; state <= ST_RESP_WAIT; end
                end

                ST_RESP_WAIT: begin
                    if (!din_s) begin us_cnt <= 22'd0; state <= ST_RESP_LOW; end
                end

                ST_RESP_LOW: begin
                    if (din_s) begin us_cnt <= 22'd0; state <= ST_RESP_HIGH; end
                end

                ST_RESP_HIGH: begin
                    if (!din_s) begin
                        bit_cnt <= 6'd0;
                        us_cnt  <= 22'd0;
                        state   <= ST_BIT_LOW;
                    end
                end

                ST_BIT_LOW: begin
                    if (din_s) begin us_cnt <= 22'd0; state <= ST_BIT_HIGH; end
                end

                // Decode each bit from the length of its high pulse
                ST_BIT_HIGH: begin
                    if (!din_s) begin
                        shift  <= {shift[38:0], (us_cnt >= BIT_THRESH_US)};
                        us_cnt <= 22'd0;
                        if (bit_cnt == 6'd39) begin
                            state <= ST_CHECK;
                        end else begin
                            bit_cnt <= bit_cnt + 1'b1;
                            state   <= ST_BIT_LOW;
                        end
                    end
                end

                // Check the checksum and save valid readings
                ST_CHECK: begin
                    if (frame_ok) begin
                        humidity    <= humidity_corrected;
                        temp_c      <= temp_deci / 16'd10;
                        temp_tenths <= temp_deci % 16'd10;
                        data_valid  <= 1'b1;
                        read_ok     <= 1'b1;
                    end else begin
                        read_ok     <= 1'b0;
                    end
                    us_cnt <= 22'd0;
                    state  <= ST_WAIT;
                end

                // Wait before requesting the next reading
                ST_WAIT: begin
                    if (us_cnt >= POLL_US) begin
                        us_cnt <= 22'd0;
                        state  <= ST_START_LOW;
                    end
                end

                default: begin
                    us_cnt <= 22'd0;
                    state  <= ST_WAIT;
                end
            endcase

            // Retry later if the sensor stops responding
            if (timeout && state >= ST_REL_HIGH && state <= ST_BIT_HIGH) begin
                us_cnt  <= 22'd0;
                state   <= ST_WAIT;
                read_ok <= 1'b0;
            end
        end
    end

endmodule
