
// adc_reader.v
// Reads the AD8232 signal through the DE0-Nano's 12-bit ADC.
// Samples channel 0 at 200 Hz using a 1 MHz serial clock.

module adc_reader #(
    parameter integer SAMPLE_HZ = 200
)(
    input wire clk,
    input wire rst_n,
    output reg adc_cs_n,
    output reg adc_sclk,
    output reg adc_din,
    input wire adc_dout,
    output reg [11:0] adc_value,
    output reg adc_valid
);
    localparam integer HALF_PERIOD = 25;
    localparam integer SAMPLE_PERIOD = 50_000_000 / SAMPLE_HZ;

    reg [19:0] sample_timer;
    reg [5:0] clock_timer;
    reg [4:0] bit_count;
    reg [15:0] shift_reg;
    reg busy;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            adc_cs_n <= 1'b1;
            adc_sclk <= 1'b1;
            adc_din <= 1'b0;
            adc_value <= 12'd0;
            adc_valid <= 1'b0;
            sample_timer <= 0;
            clock_timer <= 0;
            bit_count <= 0;
            shift_reg <= 0;
            busy <= 1'b0;
        end else begin
            adc_valid <= 1'b0;

            // Start a new conversion at the selected sample rate
            if (!busy) begin
                adc_cs_n <= 1'b1;
                adc_sclk <= 1'b1;
                if (sample_timer == SAMPLE_PERIOD - 1) begin
                    sample_timer <= 0;
                    clock_timer <= 0;
                    bit_count <= 0;
                    shift_reg <= 0;
                    busy <= 1'b1;
                    adc_cs_n <= 1'b0;
                    adc_din <= 1'b0;  // Select ADC channel 0
                end else
                    sample_timer <= sample_timer + 1'b1;

            end else if (clock_timer == HALF_PERIOD - 1) begin
                clock_timer <= 0;
                adc_sclk <= ~adc_sclk;

                // Read each bit on the rising ADC clock edge
                if (!adc_sclk) begin
                    shift_reg <= {shift_reg[14:0], adc_dout};

                    // Save the 12-bit reading after the final bit
                    if (bit_count == 15) begin
                        adc_value <= {shift_reg[10:0], adc_dout};
                        adc_valid <= 1'b1;
                        adc_cs_n <= 1'b1;
                        busy <= 1'b0;
                    end else
                        bit_count <= bit_count + 1'b1;
                end
            end else
                clock_timer <= clock_timer + 1'b1;
        end
    end
endmodule
