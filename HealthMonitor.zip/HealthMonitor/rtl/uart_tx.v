
// uart_tx.v
// Sends 8-bit data over UART with one start bit and one stop bit.
// The TX line stays high when nothing is being transmitted.

module uart_tx #(
    parameter CLK_HZ = 50_000_000,
    parameter BAUD = 9600
)(
    input wire clk,
    input wire rst_n,
    input wire start,
    input wire [7:0] data,
    output reg busy,
    output reg txd
);

    // Set the number of clock cycles per UART bit
    localparam integer DIV = CLK_HZ / BAUD;
    reg [$clog2(DIV)-1:0] cnt;
    reg [3:0] bitn;
    reg [9:0] sh;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            txd <= 1'b1;
            busy <= 1'b0;
            cnt <= 0;
            bitn <= 0;
            sh <= 10'h3FF;

        end else if (!busy) begin
            txd <= 1'b1;

            // Load a new character when the transmitter is ready
            if (start) begin
                sh <= {1'b1, data, 1'b0};
                busy <= 1'b1;
                cnt <= 0;
                bitn <= 0;
            end
        end else begin
            txd <= sh[0];

            // Shift out the next bit at the selected baud rate
            if (cnt == DIV - 1) begin
                cnt <= 0;
                sh <= {1'b1, sh[9:1]};

                // Clear the busy flag after the stop bit
                if (bitn == 9)
                    busy <= 1'b0;
                else
                    bitn <= bitn + 1'b1;
            end else
                cnt <= cnt + 1'b1;
        end
    end
endmodule
