
// hr_detect.v
// Filters ECG readings and detects heartbeats to estimate BPM.
// Uses an adaptive threshold and recent beat intervals.

module hr_detect #(
    parameter CLK_HZ    = 50_000_000,
    parameter SAMPLE_HZ = 200,          // Match the ADC sampling rate
    parameter MIN_THR   = 24            // Minimum peak threshold
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire [11:0] sample,
    input  wire        sample_valid,
    input  wire        leads_off,
    output reg  [7:0]  bpm,
    output reg         bpm_valid,
    output reg         beat,
    output wire        beat_led
);

    // Timing settings based on the sample rate
    localparam integer REFRACT   = SAMPLE_HZ / 4;
    localparam integer PULSE_MAX = SAMPLE_HZ / 5;
    localparam integer LEARN     = SAMPLE_HZ * 2;
    localparam integer RR_MAX    = SAMPLE_HZ * 2;
    localparam integer NOBEAT    = SAMPLE_HZ * 3;
    localparam integer DIV_K     = SAMPLE_HZ * 60;
    localparam [11:0]  MIN_THR_W = MIN_THR;

    // Store filtered readings, detected peaks and beat intervals
    reg               lo_m, lo_s;
    reg               init;
    reg        [11:0] x1, x2, x3;
    reg        [19:0] base_acc;
    reg         [9:0] learn_cnt;
    reg signed [13:0] learn_max;
    reg        [15:0] pk_q;
    reg         [9:0] rr_cnt;
    reg               have_prev;
    reg         [7:0] refr;
    reg               in_pulse, upd;
    reg         [7:0] plen;
    reg signed [13:0] pk_cur;
    reg         [9:0] rr0, rr1, rr2, rr3;
    reg         [2:0] rr_n;
    reg         [2:0] rej;
    reg         [1:0] dstate;
    reg        [16:0] rem;
    reg        [11:0] den;
    reg         [7:0] q;
    reg        [22:0] led_cnt;

    localparam [1:0] D_IDLE = 2'd0, D_LOAD = 2'd1, D_RUN = 2'd2;

    // Synchronise the electrode status input
    always @(posedge clk) begin
        lo_m <= leads_off;
        lo_s <= lo_m;
    end

    // Average four samples and remove the slowly changing baseline
    wire        [13:0] sum4 = sample + x1 + x2 + x3;
    wire        [11:0] y    = init ? sample : sum4[13:2];

    wire signed [20:0] base_err  = $signed({1'b0, y, 8'b0}) - $signed({1'b0, base_acc});
    wire signed [20:0] base_next = init ? $signed({1'b0, y, 8'b0})
                                        : $signed({1'b0, base_acc}) + (base_err >>> 8);
    wire signed [13:0] hp = $signed({2'b00, y}) - $signed({2'b00, base_next[19:8]});

    // Adjust the detection threshold based on recent peak heights
    wire        [15:0] thr_q   = (pk_q >> 1) + (pk_q >> 3);
    wire        [11:0] thr_raw = thr_q[15:4];
    wire        [11:0] thr     = (thr_raw < MIN_THR_W) ? MIN_THR_W : thr_raw;
    wire signed [13:0] thr_s   = $signed({2'b00, thr});

    // Track the time between beats and prevent double detection
    wire [9:0] rr_now   = (rr_cnt == 10'd1023) ? rr_cnt : rr_cnt + 1'b1;
    wire [7:0] refr_now = (refr != 8'd0) ? refr - 1'b1 : 8'd0;
    wire [7:0] plen_now = plen + 1'b1;

    // Update the estimated peak height
    wire signed [13:0] pk_cur_now = (hp > pk_cur) ? hp : pk_cur;
    wire        [15:0] pk_cur_q   = {pk_cur_now[11:0], 4'b0000};
    wire        [16:0] pk_x2      = {pk_q, 1'b0};
    wire        [16:0] pkc_q      = ({1'b0, pk_cur_q} < pk_x2) ? {1'b0, pk_cur_q} : pk_x2;
    wire signed [18:0] pk_diff    = $signed({2'b00, pkc_q}) - $signed({3'b000, pk_q});
    wire signed [18:0] pk_next    = $signed({3'b000, pk_q}) + (pk_diff >>> 2);

    // Compare new beat intervals with the recent average
    wire [11:0] sum_rr  = rr0 + rr1 + rr2 + rr3;
    wire [17:0] rr_x_n  = rr_now * rr_n;
    wire [17:0] lhs     = rr_x_n << 3;
    wire [17:0] rhs_lo  = ({6'b0, sum_rr} << 2) + sum_rr;
    wire [17:0] rhs_hi  = ({6'b0, sum_rr} << 3) + ({6'b0, sum_rr} << 2);
    wire too_long  = (rr_now > RR_MAX);
    wire too_short = (rr_n != 3'd0) && (lhs < rhs_lo);
    wire too_var   = (rr_n != 3'd0) && (lhs > rhs_hi);

    wire signed [13:0] learn_max_now = (hp > learn_max) ? hp : learn_max;

    assign beat_led = (led_cnt != 23'd0);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            bpm        <= 8'd0;
            bpm_valid  <= 1'b0;
            beat       <= 1'b0;
            init       <= 1'b1;
            x1 <= 12'd0; x2 <= 12'd0; x3 <= 12'd0;
            base_acc   <= 20'd0;
            learn_cnt  <= 10'd0;
            learn_max  <= 14'sd0;
            pk_q       <= 16'd0;
            rr_cnt     <= 10'd0;
            have_prev  <= 1'b0;
            refr       <= 8'd0;
            in_pulse   <= 1'b0;
            upd        <= 1'b0;
            plen       <= 8'd0;
            pk_cur     <= 14'sd0;
            rr0 <= 10'd0; rr1 <= 10'd0; rr2 <= 10'd0; rr3 <= 10'd0;
            rr_n       <= 3'd0;
            rej        <= 3'd0;
            dstate     <= D_IDLE;
            rem        <= 17'd0;
            den        <= 12'd0;
            q          <= 8'd0;
            led_cnt    <= 23'd0;
        end else begin
            beat <= 1'b0;

            // Keep the heartbeat LED on briefly after each detected beat
            if (beat)                    led_cnt <= CLK_HZ / 10;
            else if (led_cnt != 23'd0)   led_cnt <= led_cnt - 1'b1;

            // Calculate BPM from the average beat interval
            case (dstate)
                D_IDLE: ;
                D_LOAD: begin
                    rem    <= rr_n * DIV_K;
                    den    <= sum_rr;
                    q      <= 8'd0;
                    dstate <= D_RUN;
                end
                D_RUN: begin
                    if (den != 12'd0 && rem >= den) begin
                        rem <= rem - den;
                        if (q != 8'd255) q <= q + 1'b1;
                    end else begin
                        bpm       <= (rr_n >= 3'd2) ? q : 8'd0;
                        bpm_valid <= (rr_n >= 3'd2);
                        dstate    <= D_IDLE;
                    end
                end
                default: dstate <= D_IDLE;
            endcase

            // Reset the detection history if electrodes are disconnected
            if (lo_s) begin
                bpm       <= 8'd0;
                bpm_valid <= 1'b0;
                init      <= 1'b1;
                learn_cnt <= 10'd0;
                learn_max <= 14'sd0;
                pk_q      <= 16'd0;
                rr_cnt    <= 10'd0;
                have_prev <= 1'b0;
                refr      <= 8'd0;
                in_pulse  <= 1'b0;
                rr0 <= 10'd0; rr1 <= 10'd0; rr2 <= 10'd0; rr3 <= 10'd0;
                rr_n      <= 3'd0;
                rej       <= 3'd0;
                dstate    <= D_IDLE;

            end else if (sample_valid) begin

                // Update the filters with each new ADC sample
                if (init) begin
                    x1 <= sample; x2 <= sample; x3 <= sample;
                    init <= 1'b0;
                end else begin
                    x3 <= x2; x2 <= x1; x1 <= sample;
                end
                base_acc <= base_next[19:0];

                // Learn the initial R-peak height over two seconds
                if (learn_cnt < LEARN) begin
                    learn_cnt <= learn_cnt + 1'b1;
                    learn_max <= learn_max_now;
                    if (learn_cnt == LEARN - 1) begin
                        pk_q      <= {learn_max_now[11:0], 4'b0000};
                        rr_cnt    <= 10'd0;
                        have_prev <= 1'b0;
                    end
                end else begin
                    rr_cnt <= rr_now;
                    refr   <= refr_now;

                    // Clear the BPM reading if no heartbeat is detected
                    if (rr_now >= NOBEAT && rr_n != 3'd0) begin
                        rr0 <= 10'd0; rr1 <= 10'd0; rr2 <= 10'd0; rr3 <= 10'd0;
                        rr_n      <= 3'd0;
                        bpm       <= 8'd0;
                        bpm_valid <= 1'b0;
                    end

                    // Lower the threshold if no beats are detected for a while
                    if (rr_now > RR_MAX && !in_pulse)
                        pk_q <= pk_q - (pk_q >> 8);

                    if (in_pulse) begin

                        // Track a peak until the signal drops below the threshold
                        plen <= plen_now;
                        if (hp > pk_cur) pk_cur <= hp;
                        if (hp < thr_s || plen_now >= PULSE_MAX) begin
                            in_pulse <= 1'b0;
                            if (upd) pk_q <= pk_next[15:0];
                        end

                    end else if (hp > thr_s && refr_now == 8'd0) begin
                        refr <= REFRACT;

                        if (!have_prev) begin

                            // First beat gives us a starting point
                            have_prev <= 1'b1;
                            rr_cnt    <= 10'd0;
                            in_pulse <= 1'b1; plen <= 8'd0; pk_cur <= hp; upd <= 1'b1;
                            beat     <= 1'b1;

                        end else if (too_long) begin

                            // Restart if the gap between beats is too long
                            rr0 <= 10'd0; rr1 <= 10'd0; rr2 <= 10'd0; rr3 <= 10'd0;
                            rr_n      <= 3'd0;
                            rej       <= 3'd0;
                            rr_cnt    <= 10'd0;
                            bpm       <= 8'd0;
                            bpm_valid <= 1'b0;
                            in_pulse <= 1'b1; plen <= 8'd0; pk_cur <= hp; upd <= 1'b1;
                            beat     <= 1'b1;

                        end else if (too_short) begin

                            // Ignore peaks that occur too soon after the last beat
                            if (rej != 3'd0) begin

                                // Relearn the rate if the mismatch keeps happening
                                rr0 <= 10'd0; rr1 <= 10'd0; rr2 <= 10'd0; rr3 <= 10'd0;
                                rr_n      <= 3'd0;
                                rej       <= 3'd0;
                                rr_cnt    <= 10'd0;
                                bpm       <= 8'd0;
                                bpm_valid <= 1'b0;
                            end else begin
                                rej <= 3'd2;
                            end

                        end else if (too_var) begin

                            // Skip intervals much longer than the recent average
                            rr_cnt   <= 10'd0;
                            in_pulse <= 1'b1; plen <= 8'd0; pk_cur <= hp; upd <= 1'b1;
                            beat     <= 1'b1;
                            if (rej != 3'd0) begin
                                rr0 <= 10'd0; rr1 <= 10'd0; rr2 <= 10'd0; rr3 <= 10'd0;
                                rr_n      <= 3'd0;
                                rej       <= 3'd0;
                                bpm       <= 8'd0;
                                bpm_valid <= 1'b0;
                            end else begin
                                rej <= 3'd2;
                            end

                        end else begin

                            // Save valid intervals and update the heart rate
                            rr3 <= rr2; rr2 <= rr1; rr1 <= rr0; rr0 <= rr_now;
                            rr_n   <= (rr_n == 3'd4) ? 3'd4 : rr_n + 1'b1;
                            rr_cnt <= 10'd0;
                            rej    <= (rej != 3'd0) ? rej - 1'b1 : 3'd0;
                            in_pulse <= 1'b1; plen <= 8'd0; pk_cur <= hp; upd <= 1'b1;
                            beat     <= 1'b1;
                            dstate   <= D_LOAD;
                        end
                    end
                end
            end
        end
    end

endmodule
