
// health_monitor_top.v
// Connects the accelerometer, ECG and DHT11 modules.
// All readings are sent through one shared UART connection.

module health_monitor_top (
    input  wire CLOCK_50,
    input  wire KEY0,
    inout  wire DHT_DATA,
    output wire ADC_CS_N,
    output wire ADC_SCLK,
    output wire ADC_DIN,
    input  wire ADC_DOUT,
    output wire G_SENSOR_CS_N,
    output wire I2C_SCLK,
    inout  wire I2C_SDAT,
    output wire UART_TXD,
    output wire MOVEMENT,
    output wire [7:0] LED
);

    // Read acceleration and detect movement
    wire signed [15:0] ax, ay, az;
    wire accel_valid;
    wire moving;
    wire [15:0] activity_level;

    adxl345_ctrl #(.CLK_HZ(50_000_000), .SAMPLE_HZ(100)) u_accel (
        .clk(CLOCK_50), .rst_n(KEY0),
        .accel_x(ax), .accel_y(ay), .accel_z(az),
        .data_valid(accel_valid),
        .spi_csn(G_SENSOR_CS_N), .spi_sclk(I2C_SCLK),
        .spi_sdio(I2C_SDAT)
    );

    activity_detect #(
        .THRESHOLD(16'd64), .ON_COUNT(4'd3), .HOLD_SAMPLES(8'd100)
    ) u_activity (
        .clk(CLOCK_50), .rst_n(KEY0), .data_valid(accel_valid),
        .accel_x(ax), .accel_y(ay), .accel_z(az),
        .moving(moving), .activity_level(activity_level)
    );

    assign MOVEMENT = moving;

    // Read the AD8232 ECG signal through the onboard ADC
    wire [11:0] ecg_raw;
    wire ecg_valid;

    adc_reader #(.SAMPLE_HZ(200)) u_adc (
        .clk(CLOCK_50), .rst_n(KEY0),
        .adc_cs_n(ADC_CS_N), .adc_sclk(ADC_SCLK),
        .adc_din(ADC_DIN), .adc_dout(ADC_DOUT),
        .adc_value(ecg_raw), .adc_valid(ecg_valid)
    );

    // Process ECG samples to estimate heart rate
    wire [7:0] bpm;
    wire bpm_valid;
    wire beat;
    wire beat_led;

    // Lead-off detection is disabled because the pins are not connected
    hr_detect #(.CLK_HZ(50_000_000), .SAMPLE_HZ(200)) u_hr (
        .clk(CLOCK_50), .rst_n(KEY0),
        .sample(ecg_raw), .sample_valid(ecg_valid),
        .leads_off(1'b0),
        .bpm(bpm), .bpm_valid(bpm_valid),
        .beat(beat), .beat_led(beat_led)
    );

    // Read temperature and humidity from the DHT11
    wire [7:0] temp_c;
    wire [3:0] temp_tenths;
    wire [7:0] humidity;
    wire temp_data_valid;
    wire dht_ok;

    dht11_reader #(.CLK_HZ(50_000_000)) u_dht (
        .clk(CLOCK_50), .rst_n(KEY0), .dht_data(DHT_DATA),
        .temp_c(temp_c), .temp_tenths(temp_tenths),
        .humidity(humidity), .data_valid(temp_data_valid), .read_ok(dht_ok)
    );

    // Flag temperature readings that are more than 6 seconds old
    localparam [28:0] DHT_STALE_CLKS = 29'd300_000_000;
    reg [28:0] dht_age;
    reg dht_seen;
    reg ecg_seen;

    always @(posedge CLOCK_50 or negedge KEY0) begin
        if (!KEY0) begin
            dht_age <= 0;
            dht_seen <= 0;
            ecg_seen <= 0;
        end else begin
            if (temp_data_valid) begin
                dht_age <= 0;
                dht_seen <= 1'b1;
            end else if (dht_age < DHT_STALE_CLKS)
                dht_age <= dht_age + 1'b1;

            if (ecg_valid)
                ecg_seen <= 1'b1;
        end
    end

    wire temp_recent = dht_seen && (dht_age < DHT_STALE_CLKS) && dht_ok;

    // Fault bits: invalid BPM, invalid DHT or missing ADC samples
    wire [7:0] faults = {5'd0, ~ecg_seen, ~temp_recent, ~bpm_valid};

    // Combine the sensor readings into one UART packet
    wire frame_done;
    health_packet_tx #(.CLK_HZ(50_000_000), .BAUD(9600), .UPDATE_HZ(10)) u_packet (
        .clk(CLOCK_50), .rst_n(KEY0),
        .bpm(bpm), .bpm_valid(bpm_valid),
        .temp_c(temp_c), .temp_tenths(temp_tenths),
        .humidity(humidity), .moving(moving), .faults(faults),
        .accel_x(ax), .accel_y(ay), .accel_z(az), .ecg_raw(ecg_raw),
        .txd(UART_TXD), .frame_done(frame_done)
    );

    // LEDs show movement, sensor status, heartbeat and UART activity
    reg frame_seen;
    always @(posedge CLOCK_50 or negedge KEY0) begin
        if (!KEY0) frame_seen <= 1'b0;
        else if (frame_done) frame_seen <= ~frame_seen;
    end

    assign LED[0] = moving;
    assign LED[1] = temp_recent;
    assign LED[2] = ecg_seen;
    assign LED[3] = bpm_valid;
    assign LED[4] = beat_led;
    assign LED[5] = ~temp_recent;
    assign LED[6] = |faults;
    assign LED[7] = frame_seen;

endmodule
