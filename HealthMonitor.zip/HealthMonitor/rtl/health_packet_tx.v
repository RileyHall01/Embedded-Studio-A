
// health_packet_tx.v
// Combines all sensor readings into one checksummed UART packet.
// Sends 10 updates per second using a single transmitter.
// ECG is a snapshot, not a continuous waveform.

module health_packet_tx #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD = 9600,
    parameter integer UPDATE_HZ = 10
)(
    input wire clk, rst_n,
    input wire [7:0] bpm,
    input wire bpm_valid,
    input wire [7:0] temp_c,
    input wire [3:0] temp_tenths,
    input wire [7:0] humidity,
    input wire moving,
    input wire signed [15:0] accel_x, accel_y, accel_z,
    input wire [11:0] ecg_raw,
    input wire [7:0] faults,
    output wire txd,
    output reg frame_done
);

    localparam integer PERIOD = CLK_HZ / UPDATE_HZ;
    reg [25:0] period_cnt;
    reg [6:0] pos;
    reg [1:0] state;
    localparam [1:0] S_IDLE=0, S_LAUNCH=1, S_WAIT_BUSY=2, S_WAIT_DONE=3;

    reg [7:0] bpm_s, temp_s, hum_s, fault_s;
    reg [3:0] temp_dec_s;
    reg move_s;
    reg signed [15:0] ax_s, ay_s, az_s;
    reg [11:0] ecg_s;
    reg [7:0] checksum;

    // Convert decimal and hexadecimal digits to ASCII
    function [7:0] digit;
        input [15:0] n;
        begin digit = 8'h30 + n[3:0]; end
    endfunction

    function [7:0] hexchar;
        input [3:0] n;
        begin hexchar = (n < 4'd10) ? (8'h30 + n) : (8'h37 + n); end
    endfunction

    // Get the positive magnitude of each acceleration value
    wire [15:0] xmag = ax_s[15] ? (~ax_s + 16'd1) : ax_s;
    wire [15:0] ymag = ay_s[15] ? (~ay_s + 16'd1) : ay_s;
    wire [15:0] zmag = az_s[15] ? (~az_s + 16'd1) : az_s;

    wire [7:0] hr = bpm_s;
    wire [7:0] t = (temp_s > 99) ? 8'd99 : temp_s;
    wire [7:0] h = (hum_s > 100) ? 8'd100 : hum_s;

    // Build the packet one character at a time
    reg [7:0] ch;
    always @(*) begin
        case (pos)
            7'd0: ch = "$";
            7'd1: ch = "H";
            7'd2: ch = "R";
            7'd3: ch = "=";
            7'd4: ch = digit(hr / 100);
            7'd5: ch = digit((hr / 10) % 10);
            7'd6: ch = digit(hr % 10);
            7'd7: ch = ",";
            7'd8: ch = "T";
            7'd9: ch = "=";
            7'd10: ch = digit(t / 10);
            7'd11: ch = digit(t % 10);
            7'd12: ch = ".";
            7'd13: ch = digit({12'd0,temp_dec_s});
            7'd14: ch = ",";
            7'd15: ch = "H";
            7'd16: ch = "=";
            7'd17: ch = digit(h / 100);
            7'd18: ch = digit((h / 10) % 10);
            7'd19: ch = digit(h % 10);
            7'd20: ch = ",";
            7'd21: ch = "M";
            7'd22: ch = "=";
            7'd23: ch = move_s ? "1" : "0";
            7'd24: ch = ",";
            7'd25: ch = "X";
            7'd26: ch = "=";
            7'd27: ch = ax_s[15] ? "-" : "+";
            7'd28: ch = digit(xmag / 10000);
            7'd29: ch = digit((xmag / 1000) % 10);
            7'd30: ch = digit((xmag / 100) % 10);
            7'd31: ch = digit((xmag / 10) % 10);
            7'd32: ch = digit(xmag % 10);
            7'd33: ch = ",";
            7'd34: ch = "Y";
            7'd35: ch = "=";
            7'd36: ch = ay_s[15] ? "-" : "+";
            7'd37: ch = digit(ymag / 10000);
            7'd38: ch = digit((ymag / 1000) % 10);
            7'd39: ch = digit((ymag / 100) % 10);
            7'd40: ch = digit((ymag / 10) % 10);
            7'd41: ch = digit(ymag % 10);
            7'd42: ch = ",";
            7'd43: ch = "Z";
            7'd44: ch = "=";
            7'd45: ch = az_s[15] ? "-" : "+";
            7'd46: ch = digit(zmag / 10000);
            7'd47: ch = digit((zmag / 1000) % 10);
            7'd48: ch = digit((zmag / 100) % 10);
            7'd49: ch = digit((zmag / 10) % 10);
            7'd50: ch = digit(zmag % 10);
            7'd51: ch = ",";
            7'd52: ch = "E";
            7'd53: ch = "=";
            7'd54: ch = digit(ecg_s / 1000);
            7'd55: ch = digit((ecg_s / 100) % 10);
            7'd56: ch = digit((ecg_s / 10) % 10);
            7'd57: ch = digit(ecg_s % 10);
            7'd58: ch = ",";
            7'd59: ch = "F";
            7'd60: ch = "=";
            7'd61: ch = hexchar(fault_s[7:4]);
            7'd62: ch = hexchar(fault_s[3:0]);
            7'd63: ch = "*";
            7'd64: ch = hexchar(checksum[7:4]);
            7'd65: ch = hexchar(checksum[3:0]);
            7'd66: ch = 8'h0D;
            7'd67: ch = 8'h0A;
            default: ch = 8'h0A;
        endcase
    end

    // Send each character through the UART transmitter
    reg uart_start;
    reg [7:0] uart_data;
    wire uart_busy;

    uart_tx #(.CLK_HZ(CLK_HZ), .BAUD(BAUD)) u_uart (
        .clk(clk), .rst_n(rst_n), .start(uart_start), .data(uart_data),
        .busy(uart_busy), .txd(txd)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            period_cnt <= 0; pos <= 0; state <= S_IDLE;
            uart_start <= 0; uart_data <= 0; frame_done <= 0;
            bpm_s <= 0; temp_s <= 0; temp_dec_s <= 0;
            hum_s <= 0; fault_s <= 0; move_s <= 0;
            ax_s <= 0; ay_s <= 0; az_s <= 0; ecg_s <= 0;
            checksum <= 0;
        end else begin
            uart_start <= 0;
            frame_done <= 0;

            if (period_cnt == PERIOD-1) period_cnt <= 0;
            else period_cnt <= period_cnt + 1'b1;

            case (state)
                // Save the latest readings before transmitting
                S_IDLE: if (period_cnt == PERIOD-1) begin
                    bpm_s <= bpm_valid ? bpm : 8'd0;
                    temp_s <= temp_c;
                    temp_dec_s <= temp_tenths;
                    hum_s <= humidity;
                    move_s <= moving;
                    ax_s <= accel_x; ay_s <= accel_y; az_s <= accel_z;
                    ecg_s <= ecg_raw;
                    fault_s <= faults;
                    checksum <= 0;
                    pos <= 0;
                    state <= S_LAUNCH;
                end

                // Start sending the next character
                S_LAUNCH: if (!uart_busy) begin
                    uart_data <= ch;
                    uart_start <= 1'b1;
                    if (pos >= 7'd1 && pos <= 7'd62)
                        checksum <= checksum ^ ch;
                    state <= S_WAIT_BUSY;
                end

                // Wait for the UART to accept and finish the byte
                S_WAIT_BUSY: if (uart_busy) state <= S_WAIT_DONE;

                S_WAIT_DONE: if (!uart_busy) begin
                    if (pos == 7'd67) begin
                        state <= S_IDLE;
                        frame_done <= 1'b1;
                    end else begin
                        pos <= pos + 1'b1;
                        state <= S_LAUNCH;
                    end
                end

                default: state <= S_IDLE;
            endcase
        end
    end
endmodule
