
//
// adxl345_ctrl.v
// Configures the ADXL345 and reads X, Y and Z acceleration over SPI.
//

module adxl345_ctrl #(
    parameter CLK_HZ    = 50_000_000,
    parameter SAMPLE_HZ = 100
)(
    input  wire clk,
    input  wire rst_n,
    output reg signed [15:0] accel_x,
    output reg signed [15:0] accel_y,
    output reg signed [15:0] accel_z,
    output reg data_valid,
    output wire spi_csn,
    output wire spi_sclk,
    inout wire spi_sdio
);

    // SPI control signals
    reg start, wr;
    reg [5:0] addr;
    reg [7:0] wdata;
    reg [2:0] nbytes;
    wire [47:0] rdata;
    wire busy, done;

    adxl345_spi3w #(.CLK_DIV(25)) u_spi (
        .clk(clk), .rst_n(rst_n),
        .start(start), .wr(wr), .addr(addr), .wdata(wdata),
        .nbytes(nbytes), .rdata(rdata), .busy(busy), .done(done),
        .spi_csn(spi_csn), .spi_sclk(spi_sclk), .spi_sdio(spi_sdio)
    );

    // Generate a pulse at the selected sample rate
    localparam integer SAMPLE_DIV = CLK_HZ / SAMPLE_HZ;
    reg [$clog2(SAMPLE_DIV)-1:0] tick_cnt;
    reg sample_tick;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tick_cnt <= 0;
            sample_tick <= 1'b0;
        end else if (tick_cnt == SAMPLE_DIV-1) begin
            tick_cnt <= 0;
            sample_tick <= 1'b1;
        end else begin
            tick_cnt <= tick_cnt + 1'b1;
            sample_tick <= 1'b0;
        end
    end

    // States for sensor setup and data acquisition
    localparam integer PWRUP_CYC = CLK_HZ / 100;
    localparam ST_PWRUP   = 3'd0,
               ST_FORMAT  = 3'd1,
               ST_RATE    = 3'd2,
               ST_MEASURE = 3'd3,
               ST_WAIT    = 3'd4,
               ST_READ    = 3'd5;

    reg [2:0] state;
    reg [$clog2(PWRUP_CYC)-1:0] pwr_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= ST_PWRUP;
            pwr_cnt <= 0;
            start <= 1'b0;
            wr <= 1'b0;
            addr <= 6'd0;
            wdata <= 8'd0;
            nbytes <= 3'd1;
            accel_x <= 16'sd0;
            accel_y <= 16'sd0;
            accel_z <= 16'sd0;
            data_valid <= 1'b0;
        end else begin
            start <= 1'b0;
            data_valid <= 1'b0;

            case (state)

            // Configure the sensor after power-up
            ST_PWRUP: begin
                if (pwr_cnt == PWRUP_CYC-1) begin
                    wr <= 1'b1; addr <= 6'h31; wdata <= 8'h48;
                    start <= 1'b1; state <= ST_FORMAT;
                end else pwr_cnt <= pwr_cnt + 1'b1;
            end

            // Set the output data rate to 100 Hz
            ST_FORMAT: if (done) begin
                wr <= 1'b1; addr <= 6'h2C; wdata <= 8'h0A;
                start <= 1'b1; state <= ST_RATE;
            end

            // Enable measurement mode
            ST_RATE: if (done) begin
                wr <= 1'b1; addr <= 6'h2D; wdata <= 8'h08;
                start <= 1'b1; state <= ST_MEASURE;
            end

            ST_MEASURE: if (done) state <= ST_WAIT;

            // Start reading when the next sample is due
            ST_WAIT: if (sample_tick && !busy) begin
                wr <= 1'b0; addr <= 6'h32; nbytes <= 3'd6;
                start <= 1'b1; state <= ST_READ;
            end

            // Combine the six bytes into signed X, Y and Z values
            ST_READ: if (done) begin
                accel_x <= {rdata[39:32], rdata[47:40]};
                accel_y <= {rdata[23:16], rdata[31:24]};
                accel_z <= {rdata[7:0], rdata[15:8]};
                data_valid <= 1'b1;
                state <= ST_WAIT;
            end

            default: state <= ST_WAIT;
            endcase
        end
    end

endmodule
