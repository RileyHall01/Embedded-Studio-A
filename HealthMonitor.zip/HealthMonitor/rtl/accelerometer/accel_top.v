
//
// accel_top.v
// Reads acceleration data, detects movement and sends readings over UART.
// The LEDs turn on when movement is detected.
//

module accel_top (
    input wire CLOCK_50,
    input wire KEY0,
    output wire G_SENSOR_CS_N,
    output wire I2C_SCLK,
    inout wire I2C_SDAT,
    output wire [7:0] LED,
    output wire MOVEMENT,
    output wire UART_TXD
);

    wire rst_n = KEY0;
    wire signed [15:0] ax, ay, az;
    wire dv;
    wire moving;
    wire [15:0] level;

    // Read X, Y and Z acceleration at 100 Hz
    adxl345_ctrl #(.CLK_HZ(50_000_000), .SAMPLE_HZ(100)) u_ctrl (
        .clk(CLOCK_50), .rst_n(rst_n),
        .accel_x(ax), .accel_y(ay), .accel_z(az), .data_valid(dv),
        .spi_csn(G_SENSOR_CS_N), .spi_sclk(I2C_SCLK), .spi_sdio(I2C_SDAT)
    );

    // Detect movement using a threshold and hold time
    activity_detect #(
        .THRESHOLD(16'd64), .ON_COUNT(4'd3), .HOLD_SAMPLES(8'd100)
    ) u_act (
        .clk(CLOCK_50), .rst_n(rst_n), .data_valid(dv),
        .accel_x(ax), .accel_y(ay), .accel_z(az),
        .moving(moving), .activity_level(level)
    );

    // Send every tenth sample to stay within the UART bandwidth
    reg [3:0] uart_sample_count = 0;
    reg uart_data_valid = 0;

    always @(posedge CLOCK_50 or negedge rst_n) begin
        if (!rst_n) begin
            uart_sample_count <= 0;
            uart_data_valid <= 0;
        end else begin
            uart_data_valid <= 0;
            if (dv) begin
                if (uart_sample_count == 9) begin
                    uart_sample_count <= 0;
                    uart_data_valid <= 1;
                end else uart_sample_count <= uart_sample_count + 1'b1;
            end
        end
    end

    // Transmit acceleration and movement readings to the Arduino
    serial_plot #(
        .CLK_HZ(50_000_000), .BAUD(9600), .MOVING_LEVEL(16'd200)
    ) u_plot (
        .clk(CLOCK_50), .rst_n(rst_n), .data_valid(uart_data_valid),
        .accel_x(ax), .accel_y(ay), .accel_z(az), .moving(moving),
        .txd(UART_TXD)
    );

    assign MOVEMENT = moving;
    assign LED = {8{moving}};

endmodule
