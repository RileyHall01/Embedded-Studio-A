
//
// activity_detect.v
// Detects movement by comparing acceleration against a moving baseline.
// A threshold and hold time prevent the movement flag from flickering.
//

module activity_detect #(
    parameter THRESHOLD    = 16'd32,
    parameter ON_COUNT     = 4'd3,
    parameter HOLD_SAMPLES = 8'd100,
    parameter BASE_SHIFT   = 5
)(
    input wire clk,
    input wire rst_n,
    input wire data_valid,
    input wire signed [15:0] accel_x,
    input wire signed [15:0] accel_y,
    input wire signed [15:0] accel_z,
    output reg moving,
    output reg [15:0] activity_level
);

    // Track the baseline of each axis to account for gravity
    reg signed [15+BASE_SHIFT:0] base_x, base_y, base_z;
    reg init_done;

    wire signed [15:0] bx = base_x >>> BASE_SHIFT;
    wire signed [15:0] by = base_y >>> BASE_SHIFT;
    wire signed [15:0] bz = base_z >>> BASE_SHIFT;

    // Calculate how far each axis has moved from its baseline
    wire signed [16:0] dx = accel_x - bx;
    wire signed [16:0] dy = accel_y - by;
    wire signed [16:0] dz = accel_z - bz;

    wire [16:0] adx = dx[16] ? -dx : dx;
    wire [16:0] ady = dy[16] ? -dy : dy;
    wire [16:0] adz = dz[16] ? -dz : dz;

    // Combine the changes into one movement value
    wire [18:0] metric = adx + ady + adz;

    reg [3:0] on_cnt;
    reg [7:0] hold_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            base_x <= 0; base_y <= 0; base_z <= 0;
            init_done <= 1'b0;
            moving <= 1'b0;
            activity_level <= 16'd0;
            on_cnt <= 4'd0;
            hold_cnt <= 8'd0;
        end else if (data_valid) begin

            // Use the first reading to initialise the baseline
            if (!init_done) begin
                base_x <= accel_x <<< BASE_SHIFT;
                base_y <= accel_y <<< BASE_SHIFT;
                base_z <= accel_z <<< BASE_SHIFT;
                init_done <= 1'b1;
            end else begin

                // Slowly update the baseline as the board changes orientation
                base_x <= base_x + dx;
                base_y <= base_y + dy;
                base_z <= base_z + dz;

                activity_level <= (metric > 19'd65535) ? 16'hFFFF : metric[15:0];

                // Confirm movement over multiple samples
                if (metric > {3'b000, THRESHOLD}) begin
                    hold_cnt <= HOLD_SAMPLES;
                    if (on_cnt == ON_COUNT) moving <= 1'b1;
                    else on_cnt <= on_cnt + 4'd1;
                end else begin
                    on_cnt <= 4'd0;

                    // Keep movement active briefly after motion stops
                    if (hold_cnt != 8'd0) hold_cnt <= hold_cnt - 8'd1;
                    else moving <= 1'b0;
                end
            end
        end
    end

endmodule
