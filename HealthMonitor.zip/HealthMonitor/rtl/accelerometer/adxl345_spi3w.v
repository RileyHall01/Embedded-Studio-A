
//
// adxl345_spi3w.v
// Handles 3-wire SPI communication with the ADXL345.
// The same data line is used for sending commands and receiving data.
//

module adxl345_spi3w #(
    parameter CLK_DIV = 25
)(
    input  wire        clk,
    input  wire        rst_n,

    // SPI transaction controls
    input  wire        start,
    input  wire        wr,
    input  wire [5:0]  addr,
    input  wire [7:0]  wdata,
    input  wire [2:0]  nbytes,
    output reg  [47:0] rdata,
    output reg         busy,
    output reg         done,

    // Connections to the ADXL345
    output reg         spi_csn,
    output reg         spi_sclk,
    inout  wire        spi_sdio
);

    // Drive the shared data line when sending, release it when reading
    reg sdio_oe;
    reg sdio_out;
    assign spi_sdio = sdio_oe ? sdio_out : 1'bz;

    localparam ST_IDLE = 3'd0,
               ST_CMD  = 3'd1,
               ST_DATA = 3'd2,
               ST_END  = 3'd3;

    reg [2:0]  state;
    reg [7:0]  shreg;
    reg [2:0]  bitcnt;
    reg [2:0]  bytecnt;
    reg [7:0]  clkcnt;
    reg        rd_mode;
    reg        phase;

    // Build the command byte from the operation and register address
    wire [7:0] cmd = {~wr, (nbytes > 3'd1), addr};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state    <= ST_IDLE;
            spi_csn  <= 1'b1;
            spi_sclk <= 1'b1;
            sdio_oe  <= 1'b0;
            sdio_out <= 1'b0;
            busy     <= 1'b0;
            done     <= 1'b0;
            rdata    <= 48'd0;
            clkcnt   <= 8'd0;
            bitcnt   <= 3'd0;
            bytecnt  <= 3'd0;
            rd_mode  <= 1'b0;
            phase    <= 1'b0;
            shreg    <= 8'd0;
        end else begin
            done <= 1'b0;

            case (state)

            // Wait for a new read or write request
            ST_IDLE: begin
                spi_csn  <= 1'b1;
                spi_sclk <= 1'b1;
                sdio_oe  <= 1'b0;
                busy     <= 1'b0;
                if (start) begin
                    busy    <= 1'b1;
                    spi_csn <= 1'b0;
                    shreg   <= cmd;
                    rd_mode <= ~wr;
                    bytecnt <= wr ? 3'd1 : nbytes;
                    bitcnt  <= 3'd7;
                    clkcnt  <= 8'd0;
                    phase   <= 1'b0;
                    state   <= ST_CMD;
                end
            end

            // Send the command byte, one bit at a time
            ST_CMD: begin
                sdio_oe <= 1'b1;
                if (clkcnt == CLK_DIV-1) begin
                    clkcnt <= 8'd0;
                    if (phase == 1'b0) begin
                        // Set the next bit on the falling clock edge
                        spi_sclk <= 1'b0;
                        sdio_out <= shreg[7];
                        phase    <= 1'b1;
                    end else begin
                        // Shift to the next bit on the rising edge
                        spi_sclk <= 1'b1;
                        shreg    <= {shreg[6:0], 1'b0};
                        phase    <= 1'b0;
                        if (bitcnt == 3'd0) begin
                            bitcnt <= 3'd7;
                            if (rd_mode) sdio_oe <= 1'b0;
                            else         shreg   <= wdata;
                            state <= ST_DATA;
                        end else
                            bitcnt <= bitcnt - 3'd1;
                    end
                end else
                    clkcnt <= clkcnt + 8'd1;
            end

            // Transfer the requested data bytes
            ST_DATA: begin
                if (clkcnt == CLK_DIV-1) begin
                    clkcnt <= 8'd0;
                    if (phase == 1'b0) begin
                        spi_sclk <= 1'b0;
                        if (!rd_mode) sdio_out <= shreg[7];
                        phase <= 1'b1;
                    end else begin
                        spi_sclk <= 1'b1;

                        // Save incoming bits or shift outgoing bits
                        if (rd_mode) rdata <= {rdata[46:0], spi_sdio};
                        else         shreg <= {shreg[6:0], 1'b0};

                        phase <= 1'b0;
                        if (bitcnt == 3'd0) begin
                            bitcnt <= 3'd7;
                            if (bytecnt == 3'd1)
                                state <= ST_END;
                            else
                                bytecnt <= bytecnt - 3'd1;
                        end else
                            bitcnt <= bitcnt - 3'd1;
                    end
                end else
                    clkcnt <= clkcnt + 8'd1;
            end

            // Finish the transaction and release the bus
            ST_END: begin
                if (clkcnt == CLK_DIV-1) begin
                    spi_csn <= 1'b1;
                    sdio_oe <= 1'b0;
                    busy    <= 1'b0;
                    done    <= 1'b1;
                    state   <= ST_IDLE;
                    clkcnt  <= 8'd0;
                end else
                    clkcnt <= clkcnt + 8'd1;
            end

            default: state <= ST_IDLE;
            endcase
        end
    end

endmodule
