
#include <SoftwareSerial.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// FPGA TX connects to Arduino D2 (9600 baud).
// Arduino sends data to the PC at 115200 baud.
SoftwareSerial fpgaSerial(2, 3);

// 0 = original packets for the GUI
// 1 = readable values for debugging
#define HUMAN_READABLE 0

char line[96];
uint8_t length = 0;
unsigned long goodFrames = 0;
unsigned long badFrames = 0;

// Convert a hexadecimal character to a number
int nibble(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return -1;
}

void processFrame(char *msg) {

  // Check the packet format and checksum
  if (msg[0] != '$') { badFrames++; return; }

  char *star = strchr(msg, '*');
  if (star == NULL || strlen(star) != 3) { badFrames++; return; }

  int hi = nibble(star[1]);
  int lo = nibble(star[2]);

  if (hi < 0 || lo < 0) { badFrames++; return; }

  uint8_t checksum = 0;
  for (char *p = msg + 1; p < star; ++p)
    checksum ^= (uint8_t)*p;

  if (checksum != (uint8_t)((hi << 4) | lo)) {
    badFrames++;
    return;
  }

  *star = '\0';

  // Extract the sensor readings
  unsigned int hr = 0, tempInt = 0, tempDec = 0;
  unsigned int humidity = 0, movement = 0, ecg = 0, fault = 0;
  int ax = 0, ay = 0, az = 0;

  int count = sscanf(msg + 1,
     "HR=%u,T=%u.%u,H=%u,M=%u,X=%d,Y=%d,Z=%d,E=%u,F=%x",
     &hr, &tempInt, &tempDec, &humidity, &movement,
     &ax, &ay, &az, &ecg, &fault);

  // Reject incomplete or invalid readings
  if (count != 10 || hr > 255 || tempInt > 99 || tempDec > 9 ||
      humidity > 100 || movement > 1 || ecg > 4095 || fault > 255) {
    badFrames++;
    return;
  }

  goodFrames++;

#if HUMAN_READABLE
  // Print the readings in an easier format
  Serial.print("HR: "); Serial.print(hr);
  Serial.print(" bpm | T: "); Serial.print(tempInt);
  Serial.print('.'); Serial.print(tempDec);
  Serial.print(" C | RH: "); Serial.print(humidity);
  Serial.print("% | Moving: "); Serial.print(movement);
  Serial.print(" | X: "); Serial.print(ax);
  Serial.print(" Y: "); Serial.print(ay);
  Serial.print(" Z: "); Serial.print(az);
  Serial.print(" | ECG ADC: "); Serial.print(ecg);
  Serial.print(" | Fault: 0x"); Serial.println(fault, HEX);
#else
  // Forward the original packet to the PC
  *star = '*';
  Serial.println(msg);
#endif
}

void setup() {
  Serial.begin(115200);
  fpgaSerial.begin(9600);

#if HUMAN_READABLE
  Serial.println("FPGA Health Monitor / ECG + DHT11 + ADXL345");
#endif
}

void loop() {

  // Read incoming FPGA data one character at a time
  while (fpgaSerial.available()) {
    char c = (char)fpgaSerial.read();

    if (c == '\n') {
      line[length] = '\0';

      if (length)
        processFrame(line);

      length = 0;

    } else if (c != '\r') {
      if (length < sizeof(line) - 1)
        line[length++] = c;
      else {
        length = 0;
        badFrames++;
      }
    }
  }
}
