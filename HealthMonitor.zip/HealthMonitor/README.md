# Integrated FPGA Health Monitor — DE0-Nano (Quartus Lite 20.1)

**Status: source integration complete; Quartus compilation and hardware verification still required.**

This single new project acquires/handles all three sensors in the DE0-Nano:

- **ADXL345:** 100 Hz three-axis acceleration acquisition and IIR-based activity classification, using the user's `adxl345_ctrl.v` and `activity_detect.v` (64 LSB threshold, 3-sample debounce, 1-second hold).
- **AD8232 ECG:** DE0-Nano onboard ADC channel 0, **200 samples/second**; supplied `hr_detect` algorithm produces BPM, beat indicator and validity. The earlier ADC-reading module was adapted from the successful 50 Hz test to 200 Hz to match the detector.
- **DHT11-style Duinotech/XC4520 module:** 2-second readings with the provided `dht11_reader` processing. The output interpretation is **provisional** for this unusual sensor (see below).
- **One unified FPGA UART → Arduino Uno → computer:** fixed-length, checksum-protected packets **10 times per second** at **9600 baud**, with Arduino USB Serial at **115200 baud**.

## New project files

Open **`HealthMonitor_Integrated.qpf`** and choose top-level entity `health_monitor_top`.

```
HealthMonitor_Integrated.qpf
HealthMonitor_Integrated.qsf
HealthMonitor_Integrated.sdc
rtl/
  health_monitor_top.v      # integrates the three sensors + LEDs
  health_packet_tx.v       # one shared UART/packet formatter
  uart_tx.v                # UART transmitter from previous working project
  adc_reader.v             # previously working ADC reader at 200 Hz
  hr_detect.v              # HR processing from user upload, unchanged
  dht11_reader.v           # reader from user upload, provisional output decode
  accelerometer/
    adxl345_ctrl.v         # user's original accelerator acquisition module
    activity_detect.v      # user's original movement detector
    adxl345_spi3w.v        # user-provided original working SPI3w driver
    accel_top.v            # user's standalone accelerator top (reference)
    serial_plot.v          # user's standalone accelerometer UART (reference)
arduino/
  HealthMonitor_Receiver.ino
 test/
  verify_packet.py
```

**Accelerometer dependency resolved:** `adxl345_spi3w.v` is now the exact original source provided by the user, replacing the previously reconstructed/unverified version. This completes the known accelerometer source dependencies. The integrated design still requires Quartus compilation and board testing. Note: the original SPI module's comment says `50 MHz / 25 = 2 MHz`, but with a half-period divisor of 25 the actual SPI clock is **1 MHz**; no functional source changes were made.
The original `accel_top.v` and `serial_plot.v` are included as standalone reference modules. The unified top directly instantiates the same supplied `adxl345_ctrl` and `activity_detect` blocks. **`serial_plot` is not instantiated** in the unified top because using it in parallel would create competing UART transmitters. Instead the shared UART packet includes sampled **X/Y/Z values and the movement flag** alongside the other health measurements.

## UART packet format

One **68-byte** packet (including framing and CRLF) every **100 ms**:

```
$HR=072,T=22.9,H=044,M=1,X=+00012,Y=-00015,Z=+00253,E=3973,F=00*1D\r\n
```

- `HR` = BPM (`000` when no valid heart rate); `T` = temperature degrees C; `H` = relative humidity % (provisional)
- `M` = movement flag; `X/Y/Z` = signed 16-bit acceleration raw samples with fixed 5 digits; `E` = **one 10Hz raw 12-bit ECG ADC snapshot**, not the full 200Hz waveform; `F` = hexadecimal fault flags.
- Fault bit 0 = BPM not valid; bit 1 = no recent valid DHT11 reading; bit 2 = ADC no sample since reset; other bits reserved.
- The two digits after `*` are the XOR of characters between `$` and `*` (exclude both markers).
- At 9600 baud, the packet occupies about **70.8 ms per 100 ms cycle**, leaving time for the next frame.

The Arduino receiver validates the frame and, by default, **forwards it unchanged** to USB Serial at 115200 for a PC GUI or Serial Monitor. Set `#define HUMAN_READABLE 1` in the sketch to display labelled fields instead. The PC GUI must be updated to accept the new extended format if it previously expected only HR/T/M/F.

## Provisional DHT11 interpretation

The user's earlier three-pin blue sensor produced checksum-valid frames such as `91,00,0A,81,1C`, with observed temperature near 22.9 C and a humidity reading of 145%, despite a much lower likely ambient humidity. The submitted `dht11_reader` rejected humidity >100 and expected standard temperature data formatting, which would discard this reading.

The adapted reader **retains its checksum and timing state machine**, but applies the experimental conversion:

- `humidity = raw_humidity >= 100 ? raw_humidity - 100 : raw_humidity`
- `temperature_tenths = raw_temperature_integer * 10 + raw_temperature_decimal_byte`

These conversions are **not manufacturer-validated**. Compare both against calibrated instruments and fix the actual sensor framing/format if different. Do not rely on them as medical readings.

## FPGA pin assignments

The integrated QSF contains all assignments; verify in Pin Planner before programming:

| Signal | Cyclone IV E pin | Details |
|---|---|---|
| CLOCK_50 | R8 | 50 MHz clock |
| KEY0 | J15 | Active-low reset |
| DHT_DATA | A3 | GPIO_03 DHT11 data |
| UART_TXD | D3 | GPIO_00 → **Arduino Uno digital D2** |
| ADC_CS_N | A10 | Onboard ADC128S022 chip select |
| ADC_SCLK | B14 | Onboard ADC serial clock |
| ADC_DIN | B10 | Onboard ADC SADDR (FPGA output) |
| ADC_DOUT | A9 | Onboard ADC SDAT (FPGA input) |
| G_SENSOR_CS_N | G5 | ADXL345 CS |
| I2C_SCLK | F2 | ADXL345 SPI clock |
| I2C_SDAT | F1 | ADXL345 3-wire SDIO |
| MOVEMENT | C3 | Optional external movement status |
| LED[0:7] | A15,A13,B13,A11,D1,F3,B1,L3 | Diagnostic LEDs |

All digital I/O is 3.3-V LVTTL (see QSF). Analogue AD8232 `OUTPUT` connects to the onboard ADC **analogue channel 0**; it must not be wired directly to a digital FPGA pin. Verify actual header orientation, sensor 3.3 V, common ground, and ADC analogue range before powering.

## LEDs

LED0 = movement, LED1 = recent DHT reading, LED2 = ADC sample observed,
LED3 = BPM valid, LED4 = stretched beat pulse, LED5 = DHT fault,
LED6 = any fault, LED7 = toggles each completed frame.

## Hardware check sequence

1. Make a **backup** of working accelerometer / DHT / ECG test projects. Work from this new project folder only.
2. Verify `rtl/accelerometer/adxl345_spi3w.v` matches your original working source (now included).
3. Open `HealthMonitor_Integrated.qpf` in Quartus. Ensure device `EP4CE22F17C6`, top `health_monitor_top` and all source files listed in the QSF.
4. Run **full compilation**, check for pin/voltage conflicts and unintended optimisation (`ADC_DOUT`, etc.). **No Quartus build has been run in this environment.**
5. With ECG electrodes **not connected to a person**, program the FPGA. Verify LED2 ADC pulse latch and temperature/acceleration values; move the board and confirm LED0 and M change.
6. Upload `arduino/HealthMonitor_Receiver.ino` to Uno. Set PC Serial Monitor to 115200 and look for complete `$HR=...` frames with valid checksum. If missing, test the SPI driver / ADC pins separately.
7. Confirm heart-rate detector using a **properly isolated ECG signal simulator**; investigate actual signal quality and clipping (earlier raw ADC readings near 3970/4095). BPM output is **not yet validated**.
8. Update GUI parser for the new frame fields. This build transmits a *10Hz ECG snapshot* only; a continuous 200Hz trace would require a more bandwidth-efficient streaming protocol or higher-rate physical UART connection.

## Safety

This is an academic **prototype**, not a medical device. **Do not attach AD8232 electrodes to a person while connected to a PC/USB/mains-referenced setup without appropriate medical-grade patient isolation and safety provisions.** The AD8232 LO+ and LO- lines were not connected in the user's first test; accordingly `leads_off` is tied inactive, so electrode disconnection can produce invalid BPM estimates.

## Static checks

`python test/verify_packet.py` checks sample frame lengths, formatting and XOR checksum. This is **not** a Verilog simulator or hardware test. The design still needs Quartus compilation and on-board validation.
