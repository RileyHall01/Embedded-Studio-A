"""Check the XOR checksum, wire length and data-format field ranges."""
from re import fullmatch


def encode(hr=72, t=22.9, h=44, m=1, x=12, y=-15, z=253, e=3973, f=0):
    s = (f'HR={hr:03d},T={t:04.1f},H={h:03d},M={m:d},'
         f'X={x:+06d},Y={y:+06d},Z={z:+06d},E={e:04d},F={f:02X}')
    cs = 0
    for c in s: cs ^= ord(c)
    return f'${s}*{cs:02X}\r\n'


samples = [encode(), encode(0, 0.0, 0, 0, -32768, 32767, 0, 0, 7),
           encode(255, 50.0, 100, 1, 0, -1, 1, 4095, 255)]
for s in samples:
    assert len(s) == 68, (len(s), s)
    assert fullmatch(r'\$HR=\d{3},T=\d{2}\.\d,H=\d{3},M=[01],'
                     r'X=[+-]\d{5},Y=[+-]\d{5},Z=[+-]\d{5},'
                     r'E=\d{4},F=[A-F0-9]{2}\*[A-F0-9]{2}\r\n', s)
    msg, ck = s[1:-2].split('*')
    v = 0
    for c in msg: v ^= ord(c)
    assert v == int(ck, 16)
    print(repr(s))
print('Sample frame + format/XOR tests passed (not an FPGA hardware simulation).')
